// selecciono los elementos HTML mediante las ID
const numeroA = document.getElementById("numeroA");
const numeroB = document.getElementById("numeroB");
const resultadoTexto = document.getElementById("resultado");
const historialLista = document.getElementById("historial");
const btnBorrarHistorial = document.getElementById("borrarHistorial");

// obtengo el historial desde localStorage o creo un array vacio
let historial = JSON.parse(localStorage.getItem("historial")) || [];

// funcion para actualizar el historial en la página
function actualizarHistorial(operacion) {
    let item = document.createElement("li");
    item.textContent = operacion;
    historialLista.appendChild(item);

    // guardar en localStorage
    historial.push(operacion);
    localStorage.setItem("historial", JSON.stringify(historial));
}

// cargar historial guardado en la página al iniciar
function cargarHistorial() {
    historialLista.innerHTML = "";
    historial.forEach(operacion => {
        let item = document.createElement("li");
        item.textContent = operacion;
        historialLista.appendChild(item);
    });
}

// funcion para borrar historial
function borrarHistorial() {
    historial = [];
    localStorage.removeItem("historial");
    historialLista.innerHTML = "";
}

// funciones matematicas
function suma(a, b) {
    return a + b;
}
function resta(a, b) {
    return a - b;
}
function multiplicacion(a, b) {
    return a * b;
}
function division(a, b) {
    if (b === 0) return "Error: División por 0";
    return a / b;
}

// funcion para manejar operaciones
function calcular(operacion) {
    let a = parseFloat(numeroA.value);
    let b = parseFloat(numeroB.value);

    if (isNaN(a) || isNaN(b)) {
        resultadoTexto.textContent = "Error: Ingresa números válidos";
        return;
    }

    let resultado;
    switch (operacion) {
        case "suma":
            resultado = suma(a, b);
            actualizarHistorial(`${a} + ${b} = ${resultado}`);
            break;
        case "resta":
            resultado = resta(a, b);
            actualizarHistorial(`${a} - ${b} = ${resultado}`);
            break;
        case "multiplicacion":
            resultado = multiplicacion(a, b);
            actualizarHistorial(`${a} * ${b} = ${resultado}`);
            break;
        case "division":
            resultado = division(a, b);
            actualizarHistorial(`${a} / ${b} = ${resultado}`);
            break;
    }

    resultadoTexto.textContent = resultado;
}

// cargar historial al inicio
cargarHistorial();

// botones
document.getElementById("sumar").addEventListener("click", () => calcular("suma"));
document.getElementById("restar").addEventListener("click", () => calcular("resta"));
document.getElementById("multiplicar").addEventListener("click", () => calcular("multiplicacion"));
document.getElementById("dividir").addEventListener("click", () => calcular("division"));
btnBorrarHistorial.addEventListener("click", borrarHistorial);
