const albumList = document.getElementById("album-list");
const albumDetail = document.getElementById("album-detail");
const albumTitle = document.getElementById("album-title");
const songList = document.getElementById("song-list");
const playlistUI = document.getElementById("playlist");

let albums = [];
let playlist = JSON.parse(localStorage.getItem("playlist")) || [];

fetch("json/grunge_albums.json")
  .then((res) => res.json())
  .then((data) => {
    albums = data.albums;
    displayAlbums();
    updatePlaylistUI();
  });

function displayAlbums() {
  albumList.innerHTML = "";
  albums.forEach((album, index) => {
    const col = document.createElement("div");
    col.className = "col-md-4";
    col.innerHTML = `
      <div class="card album-card h-100" onclick="showAlbum(${index})">
        <img src="${album.cover}" class="card-img-top" alt="${album.title}" />
        <div class="card-body text-center">
          <h5 class="card-title">${album.title} (${album.year})</h5>
          <p class="card-text">${album.artist}</p>
        </div>
      </div>
    `;
    albumList.appendChild(col);
  });
}

function showAlbum(index) {
  const album = albums[index];
  albumList.classList.add("d-none");
  albumDetail.classList.remove("d-none");
  albumTitle.textContent = `${album.title} - ${album.artist} (${album.year})`;

  songList.innerHTML = "";
  album.songs.forEach((song) => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.innerHTML = `
      <span>${song.title}</span>
      <div>
        <a href="${song.youtube}" target="_blank" class="btn btn-sm btn-primary me-2">▶️</a>
        <button class="btn btn-sm btn-success" onclick="addToPlaylist('${song.title}', '${song.youtube}')">➕</button>
      </div>
    `;
    songList.appendChild(li);
  });
}

function goBack() {
  albumDetail.classList.add("d-none");
  albumList.classList.remove("d-none");
}

function addToPlaylist(title, youtube) {
  const exists = playlist.find((s) => s.title === title);
  if (!exists) {
    playlist.push({ title, youtube });
    savePlaylist();
    updatePlaylistUI();
  }
}

function updatePlaylistUI() {
  playlistUI.innerHTML = "";
  playlist.forEach((song, index) => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.innerHTML = `
      <span>${song.title}</span>
      <div>
        <a href="${song.youtube}" target="_blank" class="btn btn-sm btn-primary me-2">▶️</a>
        <button class="btn btn-sm btn-danger" onclick="removeFromPlaylist(${index})">🗑️</button>
      </div>
    `;
    playlistUI.appendChild(li);
  });
}

function removeFromPlaylist(index) {
  playlist.splice(index, 1);
  savePlaylist();
  updatePlaylistUI();
}

function clearPlaylist() {
  Swal.fire({
    title: "¿Vaciar la playlist?",
    text: "Esta acción no se puede deshacer.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#d33",
    cancelButtonColor: "#3085d6",
    confirmButtonText: "Sí, vaciar",
    cancelButtonText: "Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      playlist = [];
      savePlaylist();
      updatePlaylistUI();
      Swal.fire("Playlist vaciada", "", "success");
    }
  });
}


function savePlaylist() {
  localStorage.setItem("playlist", JSON.stringify(playlist));
}
