# Simulador reproductor de álbumes Grunge

Este es mi proyecto final para la materia de JavaScript. Es una especie de simulador tipo Spotify, pero centrado en álbumes de rock grunge de los 90, son 6 de los más conocidos y que más marcaron al género.

## ¿Qué hace?
- Muestra varios álbumes clásicos (Nirvana, Pearl Jam, Soundgarden, etc).
- Al hacer clic en un álbum, te muestra las canciones.
- Podés escuchar cada canción (enlace a YouTube).
- Se puede agregar canciones a una playlist.
- También se pueden eliminar de la playlist.
- La playlist se guarda con localStorage, así que no se borra si cerrás la página.
- Todo funciona como una sola página (SPA).

## Tecnologías que usé
- HTML con Bootstrap para el diseño
- CSS para los estilos personalizados
- JavaScript modular
- Fetch para leer los datos desde un JSON
- localStorage para guardar la playlist

## Cómo lo uso
1. Abrís `index.html` con Live Server (no funciona abriendo directamente el HTML desde el archivo).
2. Elegís un álbum.
3. Explorás las canciones y armás tu playlist.

---

Aunque se ve simple hay bastante código atrás, lo hice porque me gustó la idea de mezclar código con música, eligiendo un género que me gusta y escucho mucho. La idea sería reproducir las canciones directamente en la página pero para no añadir tanto peso al proyecto me decanté por usar links a las canciones en youtube. Espero que sea de su agrado y desde ya muchas gracias por todo.