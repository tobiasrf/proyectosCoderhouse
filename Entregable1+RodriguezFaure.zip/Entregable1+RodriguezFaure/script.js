// Calculadora

// funciones
function suma(numeroA, numeroB){
    return (numeroA + numeroB);
};
function resta(numeroA, numeroB){
    return (numeroA - numeroB)
};
function multiplicacion(numeroA, numeroB){
    return (numeroA * numeroB)
};
function division(numeroA, numeroB){
    return (numeroA / numeroB)
};

// comienzo del programa, creo un array por ahora vacio del historial
let historial = [];

alert("Bienvenido a la calculadora, presiona Enter para comenzar a utilizarla");

while (true){
    let opcion = parseInt(prompt("Por favor coloca un número para seleccionar la operación a realizar:\n\n1 Sumar\n2 Restar\n3 Multiplicar\n4 Dividir\n5 Ver operaciones anteriores\n\n0 Salir del menu"));

    // me aseguro de que el usuario haya colocado una opcion valida, si lo hizo continúo:
    if ([0, 1, 2, 3, 4, 5].includes(opcion)){
        // suma
        if (opcion === 1){
            numeroA = parseFloat(prompt("Vas a sumar, coloca el primer numero:"));
            numeroB = parseFloat(prompt("Coloca el segundo numero:"));
            let resultado = suma(numeroA, numeroB)
            alert("El resultado es:\n\n" + resultado);
            historial.push("Suma: " + numeroA + "+" + numeroB + "=" + resultado);
        } 
        //resta
        else if (opcion === 2){
            numeroA = parseFloat(prompt("Vas a restar, coloca el primer numero:"));
            numeroB = parseFloat(prompt("Coloca el segundo numero:"));
            let resultado = resta(numeroA, numeroB)
            alert("El resultado es:\n\n" + resultado);
            historial.push("Resta: " + numeroA + "-" + numeroB + "=" + resultado);
        } 
        //multipl.
        else if (opcion === 3){
            numeroA = parseFloat(prompt("Vas a multiplicar, coloca el primer numero:"));
            numeroB = parseFloat(prompt("Coloca el segundo numero:"));
            let resultado = multiplicacion(numeroA, numeroB)
            alert("El resultado es:\n\n" + resultado);
            historial.push("Multiplcación: " + numeroA + "*" + numeroB + "=" + resultado);
        } 
        //division
        else if (opcion === 4){
            numeroA = parseFloat(prompt("Vas a dividir, coloca el primer numero:"));
            numeroB = parseFloat(prompt("Coloca el segundo numero:"));
            let resultado = division(numeroA, numeroB)
            alert("El resultado es:\n\n" + resultado);
            historial.push("División: " + numeroA + "/" + numeroB + "=" + resultado);
        } 
        //historial, lo muestro si hay operaciones, si no, se muestra un alert
        else if (opcion === 5){
            if (historial.length > 0){
                alert("Operaciones anteriores:\n\n" + historial.join("\n"));
            }
            else {
                alert("Aún no has realizado ninguna operación.");
            }
        } 
        //cierre del menu
        else if (opcion === 0){
            alert("Gracias por usar la calculadora!\n\nPara volver al menú nuevamente solo recarga la página.")
            break;
        } 
    } 
    //si la opcion no es uno de los números indicados, uso un else para reiniciar el ciclo
    else {
        alert("Opción no válida, presiona Enter para intentarlo de nuevo.");
    }
    
}

console.log(historial);
